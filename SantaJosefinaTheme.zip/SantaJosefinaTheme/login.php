<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Acceso Corporativo — Santa Josefina SpA</title>
  <link rel="stylesheet" href="css/styles.css" />
  <script src="js/app.js"></script>
  <style>
    .auth-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f7f7f7}
    .auth-card{background:#fff;width:360px;padding:28px;border-radius:6px;box-shadow:0 8px 30px rgba(0,0,0,.08)}
    .auth-title{font-size:20px;font-weight:600;color:#1A2B48;margin:0 0 6px}
    .auth-sub{color:#667085;font-size:13px;margin:0 0 18px}
    .auth-card input{width:100%;padding:10px;border:1px solid #e5e7eb;border-radius:4px;margin-bottom:12px}
    .muted{color:#8a8f98;font-size:12px;margin-top:6px}
    .err{color:#b42318;background:#fee4e2;border:1px solid #fda29b;padding:8px 10px;border-radius:4px;margin-bottom:10px;display:none}
  </style>
</head>
<body>
  <!-- NAV -->
<header class="main-header">
  <div class="navbar">
    <!-- Logo -->
    <a href="https://santajosefinaspa.cl/wp-content/themes/SantaJosefinaTheme/index.php" class="logo">
      <img src="https://santajosefinaspa.cl/wp-content/themes/SantaJosefinaTheme/assets/img/logo_santajosefina.png" alt="Logo Santa Josefina" style="width: 140px; height: auto;">
    </a>

    <!-- Links -->
    <nav class="nav-links">
      <a href="#servicios">Servicios</a>
      <a href="#copropiedad">Copropiedades</a>
      <a href="#contacto">Contacto</a>
      <a href="https://santajosefinaspa.cl/wp-content/themes/SantaJosefinaTheme/dashboard.php" class="btn-outline">Acceso Corporativo</a>
    </nav>
  </div>
</header>

  <div class="auth-wrap">
    <div class="auth-card">
      <h1 class="auth-title">Acceso Corporativo</h1>
      <p class="auth-sub">Ingresa con tu correo y contraseña registrados.</p>

      <div id="errorBox" class="err"></div>

      <form id="loginForm">
        <input type="email" id="email" placeholder="Correo corporativo" required />
        <input type="password" id="password" placeholder="Contraseña" required />
        <button type="submit" class="btn-primary" style="width:100%;">Ingresar</button>
      </form>

      <p class="muted">¿Problemas para ingresar? Contacta a tu administrador.</p>
    </div>
  </div>

  <script>
    // Si ya está logueado, redirige al panel
    if(getAuthUser()){ window.location.href = "https://santajosefinaspa.cl/wp-content/themes/SantaJosefinaTheme/dashboard.php"; }

    const form = document.getElementById('loginForm');
    const errorBox = document.getElementById('errorBox');

    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      errorBox.style.display='none'; errorBox.textContent = '';

      const email = document.getElementById('email').value.trim().toLowerCase();
      const pass  = document.getElementById('password').value;

      try{
        await loginWithAppSheet(email, pass);    // definido en js/app.js (más abajo)
        window.location.href = "dhttps://santajosefinaspa.cl/wp-content/themes/SantaJosefinaTheme/dashboard.php"; // éxito
      }catch(err){
        errorBox.textContent = err.message || 'No fue posible iniciar sesión.';
        errorBox.style.display='block';
      }
    });
  </script>
</body>
</html>